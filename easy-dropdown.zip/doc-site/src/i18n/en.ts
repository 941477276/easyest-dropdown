export default {
  codeDemonstration: 'Code demonstration',
  doc: 'Doc',
  searchInputPlacement: 'Search documents...',
  component: 'Components',
  openOnPlayground: 'Open in Playground',
  copyCode: 'Copy Code',
  shrinkCode: 'Shrink code',
  expandCode: 'Expand Code'
};
