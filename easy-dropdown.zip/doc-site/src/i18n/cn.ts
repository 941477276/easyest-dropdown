export default {
  codeDemonstration: '代码演示',
  doc: '文档',
  searchInputPlacement: '搜索文档...',
  component: '组件',
  openOnPlayground: '在Playground中打开',
  copyCode: '复制代码',
  shrinkCode: '收起代码',
  expandCode: '展开代码'
};
