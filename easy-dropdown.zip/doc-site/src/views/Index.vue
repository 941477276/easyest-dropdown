<template>
<div class="index">
  <h1>首页</h1>
  <demo-box></demo-box>
</div>
</template>

<script lang="ts">
import {
  defineComponent
} from 'vue';

export default defineComponent({
  name: 'Index',
  components: {
    // Header
  }
});
</script>

<style lang="scss" scoped>

</style>
