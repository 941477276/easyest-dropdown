
// 由 generateRoutes.js 自动构建的路由文件
/* eslint-disable */
export default [
  
    {
      path: 'dropdown-javascript',
      name: 'dropdown-javascript',
      meta: {"category":"Components","type":"工具组件","typeCode":"tool_component","title":"原生Javascript","subtitle":null},
      component: () => import('../../../src/components/bs-dropdown-javascript/demos/index.vue')
    },
    {
      path: 'dropdown-transition',
      name: 'dropdown-transition',
      meta: {"category":"Components","type":"工具组件","typeCode":"tool_component","title":"DropdownTransition","subtitle":"下拉过渡"},
      component: () => import('../../../src/components/bs-dropdown-transition/demos/index.vue')
    }
];