// 由 generateRoutes.js 自动构建的菜单文件
export interface MenuItem {
  type: string;
  typeCode: string;
  title: string;
  subtitle?: string;
  componentName: string;
};

export interface Menus {
  type: string;
  typeCode: string;
  children: MenuItem[];
}

/* eslint-disable */
let menus: Menus[] = [
{
    type: '工具组件',
    typeCode: 'tool_component',
    children: [{"type":"工具组件","typeCode":"tool_component","title":"原生Javascript","subtitle":null,"componentName":"dropdown-javascript"},{"type":"工具组件","typeCode":"tool_component","title":"DropdownTransition","subtitle":"下拉过渡","componentName":"dropdown-transition"}]
  }
];

export default menus;