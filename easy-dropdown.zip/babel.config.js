module.exports = {
  presets: [
    '@vue/app'
  ],
  plugins: [
    '@vue/babel-plugin-jsx'
  ]
};
