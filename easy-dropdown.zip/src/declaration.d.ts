declare module 'easy-dropdown'
