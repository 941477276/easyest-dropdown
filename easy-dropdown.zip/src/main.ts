import { createApp } from 'vue';

import App from './App.vue';
// import BsVue from './components/index';

const app = createApp(App);

// 初始化bootstrap组件
// initBootstrapComponents(app);
// initRouterDefend(router);
// app.use(store);
// app.use(router);
// app.use(BsVue);

app.mount('#app');
